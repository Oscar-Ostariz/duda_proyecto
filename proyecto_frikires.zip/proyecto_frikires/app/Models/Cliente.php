<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cliente extends Model
{
    use HasFactory;

    protected $fillable = ['Nombre_usuario', 'Contraseña', 'DNI_cliente', 'Nombre', 'Apellido', 'Telefono', 'Email',
        'Direccion', 'Pais', 'Provincia', 'Localidad', 'Edad'];

}
