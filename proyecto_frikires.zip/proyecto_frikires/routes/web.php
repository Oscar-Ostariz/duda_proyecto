<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/login', function () {
    return view('login');
});

Route::get('/forgotten_pass', function () {
    return view('forgotten_pass');
});

Route::get('/welcome', function () {
    return view('welcome');
});

Route::get('/registro', function () {
    return view('registro');
});

Route::post('/registro', 'App\Http\Controllers\Registro_Controller@store');

Route::get('/producto', function () {
    return view('producto');
});

Route::get('/reservas', function () {
    return view('reservas');
});

Route::get('/impresion', function () {
    return view('impresion');
});

Route::get('/datos_app', function () {
    return view('datos_app');
});

Route::get('/about_us', function () {
    return view('about_us');
});

Route::resource("cliente", App\Http\Controllers\Cliente_Controller::class);

