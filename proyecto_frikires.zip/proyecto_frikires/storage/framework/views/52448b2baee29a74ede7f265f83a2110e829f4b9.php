<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Página de bases de datos">
    <meta name="author" content="Oscar">

    <link rel="shortcut icon" type="imagen/x-icon"
          href="<?php echo e(asset('images/logos/logo.png')); ?>">

    <title>Página de datos</title>

    <!--Obtenemos la flecha del scroll-->
    <script src="https://kit.fontawesome.com/41bcea2ae3.js" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="<?php echo e(asset('css/boton/boton.css')); ?>">

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">

    <style>
        body {
            margin-bottom: 30px;
            background-color: rgb(187, 184, 184);
        }

        /**Barra de menu responsiva**/
        .menu-main {
            display: flex;
            justify-content: space-between;
            background: rgb(129, 172, 175);
            border-bottom: 1px solid rgb(129, 172, 175);
            height: 45px;
        }

        .menu-main a {
            flex: 1;
            display: flex;
            color: #ffffff;
            text-decoration: none;
            font-size: 12px;
            font-weight: bold;
            justify-content: center;
            align-items: center;
        }

        .menu-main a:hover {
            background: rgba(0, 0, 0, .1);
        }

        .menu-main a.active {
            background-color: rgb(129, 172, 175);
        }

        @media (max-width: 768px) {
            .menu-main {
                height: auto;
                border-bottom: 0px;
                display: block;
            }

            .menu-main a {
                height: 45px;
                border-bottom: 1px solid #29487d;
            }
        }

    </style>
</head>

<body>

<br/>
<a href="login" class="active" style="text-align: right; display: block; font-size: 25px "> ¡Regístrate!</a>
<br/><br/>

<div class="container-fluid">

    <div class="page-header">
        <img class="img-responsive" src="<?php echo e(asset('images/logos/logo3.png')); ?>" alt="logo"
             style="display: inline;">
    </div>

    <br/>

    <nav class="menu-main">
        <a href="/"><img class="img-responsive" alt="casa"
                         src="<?php echo e(asset('images/menu/casa.png')); ?>">Home</a>

        <a href="reservas"><img class="img-responsive" alt="reservas"
                                src="<?php echo e(asset('css/EMERGENTE/save.png')); ?>">Reservas</a>

        <a href="impresion"><img class="img-responsive" alt="impresion"
                                 src="<?php echo e(asset('images/menu/diseno.png')); ?>">¡Envíanos tus diseños!</a>

        <a href="datos_app"><img class="img-responsive" alt="datos"
                                 src="<?php echo e(asset('images/menu/BBDD.png')); ?>">Datos de las bases de datos</a>

        <a href="about_us"><img class="img-responsive" alt="about_us"
                                src="<?php echo e(asset('images/menu/about_us.png')); ?>">¿Quienes somos?</a>
    </nav>

    <br/><br/>

    <div>
        <center>
            <fieldset style="background-color: #3c763d">
                <p>Esta parte de la web estará disponible en futuras versiones</p>
            </fieldset>
        </center>
    </div>

    <br/><br/> <br/><br/> <br/><br/><br/><br/><br/>

    <!--Boton de ir hacia arriba-->
    <div id="button-up">
        <i class="fas fa-chevron-up"></i>
    </div>

</div>

<footer class="bg-dark text-center text-white" style="background-color:rgb(212, 209, 214);">

    <div class="container p-4">

        <section class="mb-4">
            <p> ¡Encuentranos en las redes sociales!</p>
        </section>

        <section class="">
            <div class="row">
                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Instagram</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://www.instagram.com/" class="text-white"><img
                                    src="<?php echo e(asset('images/iconos/insta.png')); ?>" alt="insta"></a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Facebook</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://es-es.facebook.com/" class="text-white"><img
                                    src="<?php echo e(asset('images/iconos/face.png')); ?>" alt="facebook"></a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Twitter</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://twitter.com/" class="text-white"><img
                                    src="<?php echo e(asset('images/iconos/twitter.png')); ?>" alt="twitter"></a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Google</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://www.google.es/" class="text-white"><img
                                    src="<?php echo e(asset('images/iconos/google.png')); ?>" alt="google"></a>
                        </li>
                    </ul>
                    <br/>
                </div>
            </div>
        </section>
    </div>

    <div class="text-center p-3" style="background-color: rgb(243, 240, 245);">
        © 2021 Copyright: <a class="text-white" href="/">Frikires.es</a>, Inc. o afiliados. Todos los derechos
        reservados.
    </div>

</footer>

<script src="<?php echo e(asset('css/boton/boton.js')); ?>"></script>

</body>
</html>
<?php /**PATH /var/www/html/proyecto_frikires/resources/views/datos_app.blade.php ENDPATH**/ ?>