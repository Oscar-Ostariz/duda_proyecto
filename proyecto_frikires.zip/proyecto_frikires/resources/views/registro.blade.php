<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Formulario de registro">
    <meta name="author" content="Oscar">

    <link rel="shortcut icon" type="imagen/x-icon"
          href="{{asset('images/logos/logo.png')}}">

    <title>Alta de usuario</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

    <link rel="stylesheet" href="{{asset('css/boton/boton.css')}}">

    <!-- Bootstrap core CSS -->
    <link href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet">

    <!--Obtenemos la flecha del scroll-->
    <script src="https://kit.fontawesome.com/41bcea2ae3.js" crossorigin="anonymous"></script>

    <script src="{{asset('lib/jquery.js')}}"></script>
    <script src="{{asset('lib/jquery.validate.js')}}"></script>

    <script>

        $().ready(function () {

            $("#form").validate();

            $("#form_2").validate({
                rules: {
                    nombre: {
                        required: true,
                        minlength: 5
                    },
                    password: {
                        required: true,
                        minlength: 5
                    },
                    confirmar_password: {
                        required: true,
                        minlength: 5,
                        equalTo: "#password"
                    }, email: {
                        required: true,
                        email: true
                    }, dni: {
                        required: true,
                        dni: true,
                        minlength: 9
                    },
                    agree: "required"
                },
                messages: {
                    nombre: {
                        required: "<span class='help-block'><img src='{{asset('images/iconos/warning.png')}}' alt='mal'>  El nombre es obligatorio</span>",
                        minlength: "<span class='help-block'><img src='{{asset('images/iconos/warning.png')}}' alt='mal'> El nombre es demasiado corto, ha de tener 5 caracteres.</span>",

                    }, password: {
                        required: "<span class='help-block'><img src='{{asset('images/iconos/warning.png')}}' alt='mal'>  Introduce una contraseña</span>",
                        minlength: "<span class='help-block'><img src='{{asset('images/iconos/warning.png')}}' alt='mal'>  Este campo requiere 5 carácteres como mínimo</span>"
                    },
                    confirmar_password: {
                        required: "<span class='help-block'><img src='{{asset('images/iconos/warning.png')}}' alt='mal'>  Introduce la verificación de la contraseña</span>",
                        minlength: "<span class='help-block'><img src='{{asset('images/iconos/warning.png')}}' alt='mal'>  Este campo requiere 5 carácteres como mínimo</span>",
                        equalTo: "<span class='help-block'><img src='{{asset('images/iconos/warning.png')}}' alt='mal'>  Las contraseñas han de coincidir</span>"
                    },
                    email: {
                        required: "<span class='help-block'><img src='{{asset('images/iconos/warning.png')}}' alt='mal'> La dirección de correo es incorrecta</span>",
                    },
                    dni: {
                        required: "<span class='help-block'><img src='{{asset('images/iconos/warning.png')}}' alt='mal'> Introduce el DNI</span>",
                    },
                    agree: {
                        required: "<span class='help-block'><img src='{{asset('images/iconos/warning.png')}}' alt='mal'> Por favor, acepta nuestros términos y condiciones</span>",
                    }
                }
            });
            $("#usuario").focus(function () {
                let nombre = $("#nombre").val();

                let numero = Math.random() * (110 - 1) + 1;

                if (nombre && !this.value)
                    this.value = nombre.toLocaleLowerCase() + "_" + Math.floor(numero);

            });
        });
    </script>

    <style>

        body {
            margin-bottom: 30px;
            background-color: rgb(187, 184, 184);
        }

        /**Barra de menu responsiva**/

        .menu-main {
            display: flex;
            justify-content: space-between;
            background: rgb(129, 172, 175);
            border-bottom: 1px solid rgb(129, 172, 175);
            height: 45px;
        }

        .menu-main a {
            flex: 1;
            font-family: arial, fantasy;
            display: flex;
            color: #ffffff;
            text-decoration: none;
            font-size: 12px;
            font-weight: bold;
            justify-content: center;
            align-items: center;
        }

        .menu-main a:hover {
            background: rgba(0, 0, 0, .1);
        }

        @media (max-width: 768px) {
            .menu-main {
                height: auto;
                border-bottom: 0px;
                display: block;
            }

            .menu-main a {
                height: 45px;
                border-bottom: 1px solid #29487d;
            }
        }

    </style>
</head>

<body>
<div class="container-fluid">


    <div class="page-header">
        <img class="img-responsive" src="{{asset('images/logos/logo3.png')}}" alt="logo"
             style="display: inline;">
    </div>

    <br/>

    <nav class="menu-main">
        <a href="/"><img class="img-responsive" alt="casa"
                         src="{{asset('images/menu/casa.png')}}">Home</a>

        <a href="reservas"><img class="img-responsive" alt="reservas"
                                src="{{asset('css/EMERGENTE/save.png')}}">Reservas</a>

        <a href="impresion"><img class="img-responsive" alt="impresion"
                                 src="{{asset('images/menu/diseno.png')}}">¡Envíanos tus diseños!</a>

        <a href="datos_app"><img class="img-responsive" alt="datos"
                                 src="{{asset('images/menu/BBDD.png')}}">Datos de las bases de datos</a>

        <a href="about_us"><img class="img-responsive" alt="about_us"
                                src="{{asset('images/menu/about_us.png')}}">¿Quienes somos?</a>
    </nav>

    <br/><br/>

    <br/><br/>

    <h1><i>
            <center>Formulario de alta a nuestro sitio web</center>
        </i></h1>

    <br/><br/>

    <form class="form-horizontal" action="{{route('cliente.store')}}" method="POST" id="form_2">
        @csrf
        <fieldset>

            <div class="form-group">
                <label class="col-md-4 control-label" for="nombre">Nombre:<span
                        style="color:red;">*</span></label>
                <div class="col-md-4">
                    <input id="nombre" name="nombre" type="text"
                           placeholder="Nuevo Nombre" class="form-control input-md" autofocus>
                    <span class="help-block"><img src="{{asset('images/iconos/i.png')}}"
                                                  alt="i">  Introduce tu nombre</span>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 control-label" for="apellido">Apellido:</label>
                <div class="col-md-4">
                    <div class="input-group">

                        <input id="apellido" name="apellido" class="form-control"
                               placeholder="apellido" type="text">
                    </div>
                    <span class="help-block"><img src="{{asset('images/iconos/i.png')}}"
                                                  alt="i">  Introduce tu apellido</span>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 control-label" for="password">Contraseña:<span
                        style="color:red;">*</span></label>
                <div class="col-md-4">
                    <input id="password" name="password" type="password" placeholder="Introduce la contraseña"
                           class="form-control input-md">
                    <span class="help-block"><img src="{{asset('images/iconos/i.png')}}"
                                                  alt="i">  Introduce la contraseña (5 dígitos como mínimo)</span>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 control-label" for="confirmar_password">Verifica la contraseña:<span
                        style="color:red;">*</span></label>
                <div class="col-md-4">
                    <input id="confirmar_password" name="confirmar_password" type="password"
                           placeholder="Vuelve a escribir la contraseña" class="form-control input-md">
                    <span class="help-block"><img src="{{asset('images/iconos/i.png')}}"
                                                  alt="i">  Introduce la contraseña de nuevo</span>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 control-label" for="dni">Dni del usuario:<span
                        style="color:red;">*</span></label>
                <div class="col-md-4">
                    <input id="dni" name="dni" type="text"
                           placeholder="Dni del usuario" class="form-control input-md" autofocus>
                    <span class="help-block"><img src="{{asset('images/iconos/i.png')}}"
                                                  alt="i">  Dni del usuario</span>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 control-label" for="usuario">Nombre de usuario:</label>
                <div class="col-md-4">
                    <input id="usuario" name="usuario" type="text"
                           placeholder="Nombre de usuario" class="form-control input-md" autofocus>
                    <span class="help-block"><img src="{{asset('images/iconos/i.png')}}"
                                                  alt="i"> Nombre de usuario</span>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 control-label" for="telefono">Telefono:<span
                        style="color:red;">*</span></label>
                <div class="col-md-4">
                    <div class="input-group">

                        <input id="telefono" name="telefono" class="form-control"
                               placeholder="telefono" type="tel" required>
                    </div>
                    <span class="help-block"><img src="{{asset('images/iconos/i.png')}}"
                                                  alt="i">  Introduce tu teléfono</span>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 control-label" for="email">Email:<span
                        style="color:red;">*</span></label>
                <div class="col-md-4">
                    <div class="input-group">

                        <input id="email" name="email" class="form-control"
                               placeholder="email" type="email">
                    </div>
                    <span class="help-block"><img src="{{asset('images/iconos/i.png')}}"
                                                  alt="i">  Introduce tu email</span>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 control-label" for="direccion">Dirección:<span
                        style="color:red;">*</span></label>
                <div class="col-md-4">
                    <div class="input-group">

                        <input id="direccion" name="direccion" class="form-control"
                               placeholder="direccion" type="text" required>
                    </div>
                    <span class="help-block"><img
                            src="{{asset('images/iconos/i.png')}}"
                            alt="i">  Introduce tu dirección</span>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 control-label" for="pais">País:<span
                        style="color:red;">*</span></label>
                <div class="col-md-4">
                    <div class="input-group">

                        <input id="pais" name="pais" class="form-control"
                               placeholder="pais" type="text" required>
                    </div>
                    <span class="help-block"><img
                            src="{{asset('images/iconos/i.png')}}"
                            alt="i">  Introduce tu pais</span>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 control-label" for="provincia">Provincia:<span
                        style="color:red;">*</span></label>
                <div class="col-md-4">
                    <div class="input-group">

                        <input id="provincia" name="provincia" class="form-control"
                               placeholder="provincia" type="text" required>
                    </div>
                    <span class="help-block"><img
                            src="{{asset('images/iconos/i.png')}}"
                            alt="i">  Introduce tu provincia</span>
                </div>

            </div>

            <div class="form-group">
                <label class="col-md-4 control-label" for="localidad">Localidad:<span
                        style="color:red;">*</span></label>
                <div class="col-md-4">
                    <div class="input-group" required>

                        <input id="localidad" name="localidad" class="form-control"
                               placeholder="localidad" type="text">
                    </div>
                    <span class="help-block"><img
                            src="{{asset('images/iconos/i.png')}}"
                            alt="i">  Introduce tu localidad</span>
                </div>

            </div>

            <div class="form-group">
                <label class="col-md-4 control-label" for="edad">Edad:</label>
                <div class="col-md-4">
                    <div class="input-group">

                        <input id="edad" name="edad" class="form-control"
                               placeholder="edad" type="text">
                    </div>
                    <span class="help-block"><img
                            src="{{asset('images/iconos/i.png')}}"
                            alt="i">  Introduce tu edad</span>
                </div>

            </div>

            <hr/>

            <div class="form-group">
                <label class="col-md-4 control-label" for="opcional1">¿Cómo nos conociste?</label>
                <div class="col-md-4">
                    <select id="opcional1" name="opcional1" class="form-control">
                        <option value="Por medio de un conocido">Por medio de un conocido</option>
                        <option value="Por medio de un familiar">Por medio de un familiar</option>
                        <option value="Por medio de una red social">Por medio de una red social</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 control-label">Indica tu género</label>
                <div class="col-md-4">
                    <div class="radio">
                        <label for="opcional2-0">
                            <input type="radio" name="opcional2" id="opcional2-0" value="Masculino"
                                   checked="checked">
                            Masculino
                        </label>
                    </div>

                    <div class="radio">
                        <label for="opcional2-1">
                            <input type="radio" name="opcional2" id="opcional2-1" value="Femenino">
                            Femenino
                        </label>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 control-label" for="opiniones">Opiniones</label>
                <div class="col-md-4">
                    <textarea class="form-control" id="opiniones" name="opiniones"
                              placeholder="Si tienes algún tipo de opinión o sugerencia sobre nuestra página web, ¡no dudes en escribirlo aqui! "></textarea>
                </div>
            </div>

            <br/><br/>

            <div class="form-group">
                <label class="col-md-4 control-label" for="agree">Política de privacidad:<span
                        style="color:red; display: inline">*</span></label>
                <div class="col-md-4">
                    <input type="checkbox" class="checkbox" id="agree" name="agree" style="display: inline">

                </div>
            </div>
            <br/><br/>

            <input type="submit" value="ENVIAR" id="enviar" style="margin-left: 50%"/>

        </fieldset>
    </form>

    <p><span style="color:red;">*</span>: <i>En este formulario hay campos obligatorios.</i></p>
</div>

<!--Boton de ir hacia arriba-->
<div id="button-up">
    <i class="fas fa-chevron-up"></i>
</div>

<footer class="bg-dark text-center text-white" style="background-color:rgb(212, 209, 214);">

    <div class="container p-4">

        <section class="mb-4">
            <p> ¡Encuentranos en las redes sociales!</p>
        </section>

        <section class="">
            <div class="row">
                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Instagram</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://www.instagram.com/" class="text-white"><img
                                    src="{{asset('images/iconos/insta.png')}}" alt="insta"></a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Facebook</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://es-es.facebook.com/" class="text-white"><img
                                    src="{{asset('images/iconos/face.png')}}" alt="facebook"></a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Twitter</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://twitter.com/" class="text-white"><img
                                    src="{{asset('images/iconos/twitter.png')}}" alt="twitter"></a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Google</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://www.google.es/" class="text-white"><img
                                    src="{{asset('images/iconos/google.png')}}" alt="google"></a>
                        </li>
                    </ul>
                    <br/>
                </div>
            </div>
        </section>
    </div>

    <div class="text-center p-3" style="background-color: rgb(243, 240, 245);">
        © 2021 Copyright: <a class="text-white" href="/">Frikires.es</a>, Inc. o afiliados. Todos los derechos
        reservados.
    </div>

</footer>

<script src="{{asset('css/boton/boton.js')}}"></script>

</body>
</html>

