<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Reservas">
    <meta name="author" content="Oscar">

    <link rel="shortcut icon" type="imagen/x-icon"
          href="{{asset('images/logos/logo.png')}}">

    <title>Página de reservas</title>

    <!--Obtenemos la flecha del scroll-->
    <script src="https://kit.fontawesome.com/41bcea2ae3.js" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="{{asset('css/boton/boton.css')}}">

    <!-- Bootstrap core CSS -->
    <link href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet">

    <style>
        body {
            margin-bottom: 30px;
            background-color: rgb(187, 184, 184);
        }

        /**Barra de menu responsiva**/
        .menu-main {
            display: flex;
            justify-content: space-between;
            background: rgb(129, 172, 175);
            border-bottom: 1px solid rgb(129, 172, 175);
            height: 45px;
        }

        .menu-main a {
            flex: 1;
            display: flex;
            color: #ffffff;
            text-decoration: none;
            font-size: 12px;
            font-weight: bold;
            justify-content: center;
            align-items: center;
        }

        .menu-main a:hover {
            background: rgba(0, 0, 0, .1);
        }

        .menu-main a.active {
            background-color: rgb(129, 172, 175);
        }

        @media (max-width: 768px) {
            .menu-main {
                height: auto;
                border-bottom: 0px;
                display: block;
            }

            .menu-main a {
                height: 45px;
                border-bottom: 1px solid #29487d;
            }
        }

        /**Boton de enviar**/
        #enviar {
            float: left;
            width: 10%;
            cursor: pointer;
            background-color: #00a0f4;
            color: white;
            font-size: 28px;
            font-weight: 670;
            padding-top: 22px;
            padding-bottom: 22px;
            -webkit-transition: all 0.3s;
            -moz-transition: all 0.3s;
            transition: all 0.3s;
        }

        #enviar:hover {
            background-color: rgba(0, 0, 0, 0);
            color: #000;
        }

        .transicion {
            width: 0;
            height: 88px;
            background-color: #33de80;
            -webkit-transition: .7s ease;
            -moz-transition: .7s ease;
            -o-transition: .7s ease;
            -ms-transition: .7s ease;
            transition: .7s ease;
        }

        .enviar:hover .transicion {
            width: 10%;
            background-color: #33de80;
        }

    </style>
</head>

<body>

<br/>
<a href="login" class="active" style="text-align: right; display: block; font-size: 25px "> ¡Regístrate!</a>
<br/><br/>

<div class="container-fluid">

    <div class="page-header">
        <img class="img-responsive" src="{{asset('images/logos/logo3.png')}}" alt="logo"
             style="display: inline;">
    </div>

    <br/>

    <nav class="menu-main">
        <a href="/"><img class="img-responsive" alt="casa"
                         src="{{asset('images/menu/casa.png')}}">Home</a>

        <a href="reservas"><img class="img-responsive" alt="reservas"
                                src="{{asset('css/EMERGENTE/save.png')}}">Reservas</a>

        <a href="impresion"><img class="img-responsive" alt="impresion"
                                 src="{{asset('images/menu/diseno.png')}}">¡Envíanos tus diseños!</a>

        <a href="datos_app"><img class="img-responsive" alt="datos"
                                 src="{{asset('images/menu/BBDD.png')}}">Datos de las bases de datos</a>

        <a href="about_us"><img class="img-responsive" alt="about_us"
                                src="{{asset('images/menu/about_us.png')}}">¿Quienes somos?</a>
    </nav>

    <br/><br/>

    <div class="col-lg-3 col-md-4 col-sm-6">
        <img class="img-responsive" src="{{asset('images/productos/Aloy_HZD.jpg')}}"
             alt="Aloy_reserva" style="width: 500px; height: 600px">
    </div>

    <div class="col-lg-3 col-md-4 col-sm-6" style="display: block">
        <img class="img-responsive" src="{{asset('images/productos/Drax.jpg')}}"
             alt="Drax_reserva" style=" margin-left: 50%; width: 500px; height: 600px">
    </div>

    <!--Boton de ir hacia arriba-->
    <div id="button-up">
        <i class="fas fa-chevron-up"></i>
    </div>

</div>

<div>
    <br/>
    <p style="font-size: 2em">
        <strong style="margin-left: 10%">ALOY</strong> <strong style="margin-left: 33%">DRAX</strong> <br/>
        <strong style="color: red;margin-left: 10%">59,50 €</strong>


        <strong style="color: red; margin-left: 32%">135 €</strong>
    </p>


    <hr/>

    <div class="enviar" style="margin-left: 10%">
        <input type="submit" value="PAGAR" id="enviar"/>
        <div class="transicion"></div>
    </div>
    <br/>
</div>
<footer clas
        s="bg-dark text-center text-white" style="background-color:rgb(212, 209, 214);">

    <div class="container p-4">

        <section class="mb-4">
            <p> ¡Encuentranos en las redes sociales!</p>
        </section>

        <section class="">
            <div class="row">
                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Instagram</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://www.instagram.com/" class="text-white"><img
                                    src="{{asset('images/iconos/insta.png')}}" alt="insta"></a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Facebook</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://es-es.facebook.com/" class="text-white"><img
                                    src="{{asset('images/iconos/face.png')}}" alt="facebook"></a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Twitter</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://twitter.com/" class="text-white"><img
                                    src="{{asset('images/iconos/twitter.png')}}" alt="twitter"></a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Google</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://www.google.es/" class="text-white"><img
                                    src="{{asset('images/iconos/google.png')}}" alt="google"></a>
                        </li>
                    </ul>
                    <br/>
                </div>
            </div>
        </section>
    </div>

    <div class="text-center p-3" style="background-color: rgb(243, 240, 245);">
        © 2021 Copyright: <a class="text-white" href="/">Frikires.es</a>, Inc. o afiliados. Todos los derechos
        reservados.
    </div>

</footer>

<script src="{{asset('css/boton/boton.js')}}"></script>

</body>
</html>
