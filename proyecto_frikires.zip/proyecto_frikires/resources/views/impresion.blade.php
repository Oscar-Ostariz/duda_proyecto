<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Impresión">
    <meta name="author" content="Oscar">

    <link rel="shortcut icon" type="imagen/x-icon"
          href="{{asset('images/logos/logo.png')}}">

    <title>Alta de usuario</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

    <link rel="stylesheet" href="{{asset('css/boton/boton.css')}}">

    <!-- Bootstrap core CSS -->
    <link href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet">

    <!--Obtenemos la flecha del scroll-->
    <script src="https://kit.fontawesome.com/41bcea2ae3.js" crossorigin="anonymous"></script>

    <style>

        body {
            margin-bottom: 30px;
            background-color: rgb(187, 184, 184);
        }

        /**Barra de menu responsiva**/

        .menu-main {
            display: flex;
            justify-content: space-between;
            background: rgb(129, 172, 175);
            border-bottom: 1px solid rgb(129, 172, 175);
            height: 45px;
        }

        .menu-main a {
            flex: 1;
            font-family: arial, fantasy;
            display: flex;
            color: #ffffff;
            text-decoration: none;
            font-size: 12px;
            font-weight: bold;
            justify-content: center;
            align-items: center;
        }

        .menu-main a:hover {
            background: rgba(0, 0, 0, .1);
        }

        .menu-main a.active {
            background-color: rgb(129, 172, 175);
        }

        @media (max-width: 768px) {
            .menu-main {
                height: auto;
                border-bottom: 0px;
                display: block;
            }

            .menu-main a {
                height: 45px;
                border-bottom: 1px solid #29487d;
            }
        }

    </style>
</head>

<body>
<div class="container-fluid">

    <div class="page-header">
        <img class="img-responsive" src="{{asset('images/logos/logo3.png')}}" alt="logo"
             style="display: inline;">
    </div>

    <br/>

    <nav class="menu-main">
        <a href="/"><img class="img-responsive" alt="casa"
                         src="{{asset('images/menu/casa.png')}}">Home</a>

        <a href="reservas"><img class="img-responsive" alt="reservas"
                                src="{{asset('css/EMERGENTE/save.png')}}">Reservas</a>

        <a href="impresion"><img class="img-responsive" alt="impresion"
                                 src="{{asset('images/menu/diseno.png')}}">¡Envíanos tus diseños!</a>

        <a href="datos_app"><img class="img-responsive" alt="datos"
                                 src="{{asset('images/menu/BBDD.png')}}">Datos de las bases de datos</a>

        <a href="about_us"><img class="img-responsive" alt="about_us"
                                src="{{asset('images/menu/about_us.png')}}">¿Quienes somos?</a>
    </nav>

    <br/><br/>

    <h1><i>
            <center>Formulario de impresión de vuestros diseños</center>
        </i></h1>

    <br/><br/>

    <form class="form-horizontal" action="/welcome" method="get" id="form_2">
        <fieldset>

            <div>
                <label class="col-md-4 control-label" for="archivo">Archivo a enviar: <span
                        style="color:red;">*</span></label>
                <div class="col-md-4">
                    <input id="archivo" name="archivo" type="file" autofocus required>
                </div>
            </div>

            <br/><br/>

            <div>
                <label class="col-md-4 control-label" for="archivo">Teléfono de contacto: <span
                        style="color:red;">*</span></label>
                <div class="col-md-4">
                    <input id="tel" name="tel" type="tel" required>
                </div>
            </div>

            <br/><br/>

            <div>
                <label class="col-md-4 control-label" for="archivo">Email de contacto: <span
                        style="color:red;">*</span></label>
                <div class="col-md-4">
                    <input id="email" name="email" type="email" required>
                </div>
            </div>

            <br/><br/>

            <div class="enviar">
                <input type="submit" value="ENVIAR" id="enviar" style="margin-left: 50%"/>
            </div>

        </fieldset>
    </form>

    <p><span style="color:red;">*</span>: <i>En este formulario hay campos obligatorios.</i></p>
</div>

<!--Boton de ir hacia arriba-->
<div id="button-up">
    <i class="fas fa-chevron-up"></i>
</div>

<footer class="bg-dark text-center text-white" style="background-color:rgb(212, 209, 214);">

    <div class="container p-4">

        <section class="mb-4">
            <p> ¡Encuentranos en las redes sociales!</p>
        </section>

        <section class="">
            <div class="row">
                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Instagram</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://www.instagram.com/" class="text-white"><img
                                    src="{{asset('images/iconos/insta.png')}}" alt="insta"></a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Facebook</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://es-es.facebook.com/" class="text-white"><img
                                    src="{{asset('images/iconos/face.png')}}" alt="facebook"></a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Twitter</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://twitter.com/" class="text-white"><img
                                    src="{{asset('images/iconos/twitter.png')}}" alt="twitter"></a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Google</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://www.google.es/" class="text-white"><img
                                    src="{{asset('images/iconos/google.png')}}" alt="google"></a>
                        </li>
                    </ul>
                    <br/>
                </div>
            </div>
        </section>
    </div>

    <div class="text-center p-3" style="background-color: rgb(243, 240, 245);">
        © 2021 Copyright: <a class="text-white" href="/">Frikires.es</a>, Inc. o afiliados. Todos los derechos
        reservados.
    </div>

</footer>

<script src="{{asset('css/boton/boton.js')}}"></script>

</body>
</html>
