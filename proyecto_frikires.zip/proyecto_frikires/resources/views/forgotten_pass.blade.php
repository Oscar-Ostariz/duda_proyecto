<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Oscar">

    <link rel="shortcut icon" type="imagen/x-icon"
          href="{{asset('images/logos/logo.png')}}">

    <title>Recuperación de contraseñas</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

    <link rel="stylesheet" type="text/css"
          href="{{asset('css/estilo_form_opinion.css')}}">

    <script type="text/javascript">

        /**Validamos el nombre**/
        function revisar(elemento) {
            if (elemento.value === '')
                elemento.className = 'error';
            else
                elemento.className = 'input';
        }

        function validar() {

            let datosCorrectos = true;
            let error = "";
            if (document.getElementById("nombre").value === "") {
                datosCorrectos = false;
                error = "El nombre no puede estar vacío.";
            }

            if (!datosCorrectos) {
                alert(error);
            }

            return datosCorrectos;
        }
    </script>

    <style>

        body {
            margin-bottom: 30px;
            background-color: rgb(187, 184, 184);
        }

    </style>
</head>

<body>

<div class="page-header">
    <img class="img-responsive" src="{{asset('images/logos/logo3.png')}}" alt="logo"
         style="display: inline;">
</div>

<h1><i>
        <center>Indique su nombre de usuario y le mandaremos un email de recuperación.</center>
    </i></h1>

<div id="contenedor-form">

    <form action="welcome" method="get" onsubmit="return validar()">

        <p class="nombre">
            <label for="nombre">Nombre de usuario:</label>
            <input type="text" class="input" placeholder="Nombre" id="nombre" name="nombre" onblur="revisar(this)"
                   onkeyup="revisar(this)" required minlength="5" autocomplete="off">
        </p>

        <div class="enviar">
            <input type="submit" value="ENVIAR" id="enviar"/>
            <div class="transicion"></div>
        </div>

    </form>

</div>

<footer class="bg-dark text-center text-white" style="background-color:rgb(212, 209, 214);">

    <div class="container p-4">

        <section class="mb-4">
            <p> ¡Encuentranos en las redes sociales!</p>
        </section>

        <section class="">
            <div class="row">
                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Instagram</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://www.instagram.com/" class="text-white"><img
                                    src="{{asset('images/iconos/insta.png')}}" alt="insta"></a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Facebook</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://es-es.facebook.com/" class="text-white"><img
                                    src="{{asset('images/iconos/face.png')}}" alt="facebook"></a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Twitter</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://twitter.com/" class="text-white"><img
                                    src="{{asset('images/iconos/twitter.png')}}" alt="twitter"></a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Google</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://www.google.es/" class="text-white"><img
                                    src="{{asset('images/iconos/google.png')}}" alt="google"></a>
                        </li>
                    </ul>
                    <br/>
                </div>
            </div>
        </section>
    </div>

    <div class="text-center p-3" style="background-color: rgb(243, 240, 245);">
        © 2021 Copyright: <a class="text-white" href="/">Frikires.es</a>, Inc. o afiliados. Todos los derechos
        reservados.
    </div>

</footer>

</body>
</html>
