<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use Illuminate\Http\Request;

class Cliente_Controller extends Controller
{

    public function index(Request $request)
    {
//
    }

    //Creamos el método store
    public function store(Request $request)
    {

        #$request->input() -> Aqui se guardan los datos del formulario

        $cliente = new Cliente ($request->input());

        $cliente->save($request->input());

        $cliente = Cliente::all();

        #return var_dump($_POST);
    }

} //Class Registro_Controller
