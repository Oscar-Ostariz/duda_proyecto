<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Página principal">
    <meta name="author" content="Oscar">

    <link rel="shortcut icon" type="imagen/x-icon"
          href="<?php echo e(asset('images/logos/logo.png')); ?>">

    <title>Página principal</title>

    <!--Obtenemos la flecha del scroll-->
    <script src="https://kit.fontawesome.com/41bcea2ae3.js" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="<?php echo e(asset('css/boton/boton.css')); ?>">

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!--Para las ventanas informativas-->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,600|Open+Sans" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">

    <link rel="stylesheet" href="<?php echo e(asset('css/EMERGENTE/estilos.css')); ?>">


    <style>
        body {
            margin-bottom: 30px;
            background-color: rgb(187, 184, 184);
        }

        /**Barra de menu responsiva**/
        .menu-main {
            display: flex;
            justify-content: space-between;
            background: rgb(129, 172, 175);
            border-bottom: 1px solid rgb(129, 172, 175);
            height: 45px;
        }

        .menu-main a {
            flex: 1;
            display: flex;
            color: #ffffff;
            text-decoration: none;
            font-size: 12px;
            font-weight: bold;
            justify-content: center;
            align-items: center;
        }

        .menu-main a:hover {
            background: rgba(0, 0, 0, .1);
        }

        .menu-main a.active {
            background-color: rgb(129, 172, 175);
        }

        @media (max-width: 768px) {
            .menu-main {
                height: auto;
                border-bottom: 0px;
                display: block;
            }

            .menu-main a {
                height: 45px;
                border-bottom: 1px solid #29487d;
            }
        }

        /*Imagenes automáticas*/
        button {
            background-color: rgba(189, 225, 233, 0.99);
        }

        .carrousel {
            max-width: 1000px;
            margin: 0 auto;
            display: flex;
        }

        #imagen {
            width: 100%;
            height: 800px;
            background-size: cover;
        }
    </style>

    <!--Imagenes automáticas-->
    <script>
        window.onload = function () {
            // Seleccionamos las imágenes a mostrar
            const IMAGENES = [
                'http://oscarostariz.infenlaces.com/Z_Pagina_web/img/productos/Aloy_HZD.jpg',
                'http://oscarostariz.infenlaces.com/Z_Pagina_web/img/productos/Bobba_Fett.jpg',
                'http://oscarostariz.infenlaces.com/Z_Pagina_web/img/productos/Drax.jpg',
                'http://oscarostariz.infenlaces.com/Z_Pagina_web/img/productos/GMSS.jpg',
                'http://oscarostariz.infenlaces.com/Z_Pagina_web/img/productos/HellBoy.jpg',
                'http://oscarostariz.infenlaces.com/Z_Pagina_web/img/productos/KubHub.jpg',

            ];
            const TIEMPO_INTERVALO_MILESIMAS_SEG = 3000;
            let posicionActual = 0;
            let $botonRetroceder = document.querySelector('#retroceder');
            let $botonAvanzar = document.querySelector('#avanzar');
            let $imagen = document.querySelector('#imagen');
            let $botonPlay = document.querySelector('#play');
            let $botonStop = document.querySelector('#stop');
            let intervalo;

            function pasarFoto() {
                if (posicionActual >= IMAGENES.length - 1)
                    posicionActual = 0;
                else
                    posicionActual++;
                renderizarImagen();
            }

            function retrocederFoto() {
                if (posicionActual <= 0)
                    posicionActual = IMAGENES.length - 1;
                else
                    posicionActual--;
                renderizarImagen();
            }

            function renderizarImagen() {
                $imagen.style.backgroundImage = `url(${IMAGENES[posicionActual]})`;
            }

            function playIntervalo() {
                intervalo = setInterval(pasarFoto, TIEMPO_INTERVALO_MILESIMAS_SEG);
                // Desactivamos los botones de control
                $botonAvanzar.setAttribute('disabled', true);
                $botonRetroceder.setAttribute('disabled', true);
                $botonPlay.setAttribute('disabled', true);
                $botonStop.removeAttribute('disabled');
            }

            function stopIntervalo() {
                clearInterval(intervalo);
                // Activamos los botones de control
                $botonAvanzar.removeAttribute('disabled');
                $botonRetroceder.removeAttribute('disabled');
                $botonPlay.removeAttribute('disabled');
                $botonStop.setAttribute('disabled', true);
            }

            // Eventos
            $botonAvanzar.addEventListener('click', pasarFoto);
            $botonRetroceder.addEventListener('click', retrocederFoto);
            $botonPlay.addEventListener('click', playIntervalo);
            $botonStop.addEventListener('click', stopIntervalo);

            // Iniciar
            renderizarImagen();
        }
    </script>
</head>

<body>

<br/>
<a href="login" class="active" style="text-align: right; display: block; font-size: 25px "> ¡Regístrate!</a>
<br/><br/>

<div class="container-fluid">

    <div class="page-header">
        <img class="img-responsive" src="<?php echo e(asset('images/logos/logo3.png')); ?>" alt="logo"
             style="display: inline;">
    </div>

    <br/>

    <nav class="menu-main">
        <a href="/"><img class="img-responsive" alt="casa"
                         src="<?php echo e(asset('images/menu/casa.png')); ?>">Home</a>

        <a href="reservas"><img class="img-responsive" alt="reservas"
                                src="<?php echo e(asset('css/EMERGENTE/save.png')); ?>">Reservas</a>

        <a href="impresion"><img class="img-responsive" alt="impresion"
                                 src="<?php echo e(asset('images/menu/diseno.png')); ?>">¡Envíanos tus diseños!</a>

        <a href="datos_app"><img class="img-responsive" alt="datos"
                                 src="<?php echo e(asset('images/menu/BBDD.png')); ?>">Datos de las bases de datos</a>

        <a href="about_us"><img class="img-responsive" alt="about_us"
                                src="<?php echo e(asset('images/menu/about_us.png')); ?>">¿Quienes somos?</a>
    </nav>

    <br/><br/>

    <center><h1 style="color: rgba(74,71,233,0.99)">¡OFERTAS SEMANALES!</h1></center>

    <div class="carrousel">
        <button id="retroceder">Retroceder</button>
        <div id="imagen"></div>
        <button id="avanzar">Avanzar</button>
    </div>

    <div class="controles" style="margin-left: 50%">
        <br/><br/>
        <button id="play">Iniciar</button>
        <button id="stop" disabled>Parar</button>
    </div>

    <hr/>
    <!--------------------------------------------------------------------------------------------------------------------->
    <button id="btn-abrir-popup" class="btn-abrir-popup" style="background-color: transparent; border-style: hidden">
        <img src="<?php echo e(asset('images/productos/Aloy_HZD.jpg')); ?>"
             alt="Aloy_HZD" style="width: 500px; height: 500px; margin-left: 8em">
    </button>

    <!--------------------------------------------------------------------------------------------------------------------->
    <a href="producto">
        <img src="<?php echo e(asset('images/productos/Bobba_Fett.jpg')); ?>"
             alt="Bobba_Fett" style="width: 500px; height: 500px; margin-left: 36em">
    </a>

    <!--------------------------------------------------------------------------------------------------------------------->
    <hr/>
    <!--------------------------------------------------------------------------------------------------------------------->
    <a href="producto">
        <img src="<?php echo e(asset('images/productos/Drax.jpg')); ?>"
             alt="Drax" style="width: 500px; height: 500px; margin-left: 8em">
    </a>

    <!--------------------------------------------------------------------------------------------------------------------->
    <a href="producto">
        <img src="<?php echo e(asset('images/productos/GMSS.jpg')); ?>"
             alt="GMSS" style="width: 500px; height: 500px; margin-left: 36em">
    </a>

    <!--------------------------------------------------------------------------------------------------------------------->
    <hr/>
    <!--------------------------------------------------------------------------------------------------------------------->
    <a href="producto"><img src="<?php echo e(asset('images/productos/HellBoy.jpg')); ?>"
                            alt="HellBoy" style="width: 500px; height: 500px; margin-left: 8em"></a>

    <!--------------------------------------------------------------------------------------------------------------------->
    <a href="producto"><img src="<?php echo e(asset('images/productos/KubHub.jpg')); ?>"
                            alt="KubHub" style="width: 500px; height: 500px; margin-left: 36em"></a>

    <!--------------------------------------------------------------------------------------------------------------------->


    <div class="overlay" id="overlay">
        <div class="popup" id="popup">
            <a href="#" id="btn-cerrar-popup" class="btn-cerrar-popup"><i class="fas fa-times"></i></a>

            <h4>PREVISUALIZACION DE: <strong>Aloy, de Horizon Zero Dawn</strong></h4>

            <div class="contenedor-inputs">
                <img src="<?php echo e(asset('images/productos/Aloy_HZD.jpg')); ?>" alt="Aloy_HZD"
                     style="width: 250px; height: 300px">

                <hr/>
                <p><span style="color: red;">59,50€</span></p>
                <hr/>

                <p><strong>NOMBRE DEL PRODUCTO:</strong></p>
                <p>Aloy HZD.</p>
                <hr/>
                <p><strong>VALORACIONES DEL PRODUCTO:</strong></p>
                <p>Gran producto de excelentes características</p>
                <br/>

                <button style="background-color: transparent; border-style: hidden">
                    <img
                        src="<?php echo e(asset('css/EMERGENTE/carro.png')); ?>" alt="carrito">
                    <p style="display: inline;font-size: 1.6em">Añadir producto al carrito</p>
                </button>
                <br/><br/>

                <form action="producto">
                    <input type="submit" class="btn-submit" value="Ver producto en ventana propia">
                </form>
                <br/>

            </div>
        </div>
    </div>

</div>

<script src="<?php echo e(asset('css/EMERGENTE/popup.js')); ?>"></script>
</div>


<!--Boton de ir hacia arriba-->
<div id="button-up">
    <i class="fas fa-chevron-up"></i>
</div>

<footer class="bg-dark text-center text-white" style="background-color:rgb(212, 209, 214);">

    <div class="container p-4">

        <section class="mb-4">
            <p> ¡Encuentranos en las redes sociales!</p>
        </section>

        <section class="">
            <div class="row">
                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Instagram</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://www.instagram.com/" class="text-white"><img
                                    src="<?php echo e(asset('images/iconos/insta.png')); ?>" alt="insta"></a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Facebook</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://es-es.facebook.com/" class="text-white"><img
                                    src="<?php echo e(asset('images/iconos/face.png')); ?>" alt="facebook"></a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Twitter</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://twitter.com/" class="text-white"><img
                                    src="<?php echo e(asset('images/iconos/twitter.png')); ?>" alt="twitter"></a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Google</h5>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="https://www.google.es/" class="text-white"><img
                                    src="<?php echo e(asset('images/iconos/google.png')); ?>" alt="google"></a>
                        </li>
                    </ul>
                    <br/>
                </div>
            </div>
        </section>
    </div>

    <div class="text-center p-3" style="background-color: rgb(243, 240, 245);">
        © 2021 Copyright: <a class="text-white" href="/">Frikires.es</a>, Inc. o afiliados. Todos los derechos
        reservados.
    </div>

</footer>

<script src="<?php echo e(asset('css/boton/boton.js')); ?>"></script>

</body>
</html>
<?php /**PATH /var/www/html/proyecto_frikires/resources/views/welcome.blade.php ENDPATH**/ ?>